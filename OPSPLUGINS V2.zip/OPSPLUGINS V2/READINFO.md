# Plugins

This DAW supports custom plugins written in JavaScript. Below is a basic overview of how to create and use them.

---

## Overview

Plugins are defined using a simple structure:

```js
#name "Plugin Name";
#type "instrument" | "fx";
#version "1.0";
#model "ops1";
```

Each plugin consists of two main parts:

* `#interface` → UI (Draw UI)
* `#process` → audio processing logic

---

## Requirements

* Basic knowledge of JavaScript is recommended
* Understanding of audio processing concepts helps but is not required

---

## Interface (OPS NODE LIB)

The UI is built using ops Node library.

Example:

```js
const panel = new Node({
    style: { w: 200, h: 100, bg: '#222' }
});

const knob = new Knob({
    min: 0,
    max: 1,
    value: 0.5
});

panel.add(knob);
globalRoot.add(panel); // globalRoot is output screen
```

(OPS NODE LIB) is designed to be simple and flexible.

---

## Audio Processing

The `#process` section runs per-sample.

### Instrument example:

```js
const sr = audioCtx.sampleRate;

if (!synth.phase) synth.phase = 0;
const shiftModulation =  (synth.fxShiftFreq || 1.0); // Remember to Use this if you want support of pitchshift 
const freq = 440 * Math.pow(2, (synth.noteNumber - 69) / 12) * shiftModulation;
const delta = freq / sr;

synth.phase += delta;

const signal = Math.sin(synth.phase * Math.PI * 2);

synth.outL = signal;
synth.outR = signal;
```

---

### FX example:

```js
fx.outL = fx.inL;
fx.outR = fx.inR;
```

---

## Available Objects

### Instrument (`synth`)

* `noteNumber`
* `time`
* `outL`, `outR`
* `automation`
* `disconnect`

### Effect (`fx`)

* `inL`, `inR`
* `outL`, `outR`
* `time`
* `fromStart` (global song time)
* `automation`
* `isTailActive`

---

## Automation

Parameters can be automated:

```js
const value = fx.automation?.param ?? int.param?.val;
```

---

## Notes

* Audio runs sample-by-sample
* Avoid heavy computations inside loops
* Use deterministic logic if you want consistent rendering

---

## License

Created by Kashumy

No copyright — you are free to use, modify, and share.
